% BINOMIAL file binomial.m  Generates binomial tables
% Version of 12/10/92  (Display modified 4/28/96)
% Calculates a TABLE of binomial probabilities
% for specified n, p, and row vector k,
% Uses the m-functions ibinom and cbinom.
n = input('Enter n, the number of trials ');
p = input('Enter p, the probability of success ');
k = input('Enter k, a row vector of success numbers ');
y = ibinom(n,p,k);
z = cbinom(n,p,k);
disp([' '])
disp(['    n = ',int2str(n),'    p = ' num2str(p)])
disp([' '])
H = ['    k         P(X = k)  P(X >= k)'];
disp(H)
disp([k;y;z]')