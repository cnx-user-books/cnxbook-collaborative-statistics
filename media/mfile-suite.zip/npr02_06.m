\begin{verbatim}
% file npr02_06.m
% Data for problem P2-6
minvec3
DV = [A|Ac; A|(Bc&C); A&C; Ac&B; Ac&Cc; B&Cc];
DP = [1      0.65     0.20 0.25  0.25   0.30];
TV = [((A&Cc)|(Ac&C))&Bc; ((A&Bc)|Ac)&Cc; Ac&(B|Cc)];
disp('Call for mincalc')
\end{verbatim}
