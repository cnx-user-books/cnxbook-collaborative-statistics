function [t,p] = csortv(T,P)}
\begin{verbatim}
% [t,p] = csortv(T,P)
% Version of 7/14/95
% T and P are row matrices of real values.
% The pair is sorted on T:
%   * Identical values in T are consolidated;
%   * Corresponding values in P are added.
n  = length(T);
[TS,I] = sort(T);
d  = [1 TS(2:n) - TS(1:n-1) >1e-9];
t  = TS(d);
m  = length(t) + 1;
F  = [0 cumsum(P(I))];
Fd = F([d 1]);
p  = Fd(2:m) - Fd(1:m-1);