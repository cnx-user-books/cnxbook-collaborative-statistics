% file mcalc02.m    Data for computer survey
minvec3
DV =   [A|Ac; A; B; C; A&B&C; A&C; (A&B)|(A&C)|(B&C); ...
    2*(B&C) - (A&C)];
DP = 0.001*[1000 565 515 151 51 124 212 0];   TV = [A|B|C; Ac&Bc&C];
disp('Call for mincalc')